const getters = {
  token:state =>state.user.token
}
export default getters