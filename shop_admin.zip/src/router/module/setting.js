const Layout = () => import('@/components/layout')
const setting = {
    path: '/setting',
    name: '设置',
    icon:'https://qn.ygp.sany.com.cn/icon_set_de.png',
    component: Layout,
  }
  export default setting